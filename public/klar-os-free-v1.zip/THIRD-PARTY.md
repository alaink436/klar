# Third-party components

Honesty first: the components below are open source by other authors and available for
free at their original repos. They ship here pre-configured as a convenience. What you
paid for is the assembly, the conventions, the onboarding and the adaptations, not their
work.

| Component | Author | License | Original (free) |
|-----------|--------|---------|-----------------|
| `vault/Skills/Archive/llm-council/` | tenfoldmarc (method: Andrej Karpathy's LLM Council; Claude adaptation inspired by @olelehmann) | MIT, full text in `vault/Skills/Archive/llm-council/LICENSE` | https://github.com/tenfoldmarc/llm-council-skill |

The MIT license permits redistribution, including in paid bundles, provided the copyright
and license notice are preserved; the LICENSE file next to the skill does exactly that
(the upstream repo declares MIT in its README without a separate license file; ours
reproduces the standard text with the upstream copyright). The bundled SKILL.md and
README.md are unmodified; our adaptations live separately in
`playbook/02-llm-council.md` and are part of this kit's own content.

One heads-up on the bundled README: its install instructions suggest cloning into
`~/.claude/skills/`, an auto-load directory. In this vault, skills are archived and
loaded on demand instead (see `vault/Skills/00-Skill-Registry.md` for why). Follow the
registry, not the upstream install section.

If you are an author listed here and want anything changed, one email and it's done.
