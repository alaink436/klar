# Klar OS

The working system behind Klar Studios: one solo founder, 30+ projects, 7 apps shipped to the
App Store, built with AI agents daily. This kit is that system, extracted: the vault structure,
the rule set, the LLM Council setup, the secrets proxy. All of it **free**.

The paid half is the **Klar OS Playbook**: the failure stories behind every rule, the council
adaptations from real sessions, the secrets deep-dive, and real redacted artifacts from the
actual vault. The system works completely without it; the Playbook is why it works.

**It's plain Markdown + git.** Nothing installs, nothing runs, nothing phones home. Works with
Obsidian, works without it. Built for Claude Code, adaptable to any agent that reads files.

## What's inside

```
SETUP.html      DOUBLE-CLICK THIS FIRST: your setup interface (checklist, offline)
START-HERE.md   Hand this to your AI agent, it runs the whole setup
ONBOARDING.md   Day 1 to 7, in order (the manual path)
vault/          The template vault. Copy the kit, the vault lives inside it.
  CLAUDE.md          The rule set your agent loads every session (the heart of the kit)
  STATUS.md          One-screen dashboard over all projects
  Projects/          Registry + one example project (PRD + PROGRESS)
  Learnings/         Mistakes → rules, so agents stop repeating them
  Skills/            On-demand skill archive incl. the LLM Council + the setup skill
proxy-template/ The ready-to-deploy secrets proxy (copied, not authored, by the skill)
THIRD-PARTY.md  What's not mine, under which license, and where to get it free

...... paid add-on (getklar.org) ......
playbook/       Why each rule exists: scars, council adaptations, secrets deep-dive
examples/       Real, redacted artifacts from the seller's actual vault
```

## Before you start

You need: git + a GitHub account (day 1). For the secrets setup: Node ≥ 20 and free
Vercel + Supabase accounts. An AI agent that can read files and run commands (Claude
Code or similar) makes everything smoother but only the setup skill requires one.

## Where to start

**First: double-click `SETUP.html`.** It opens in your browser (offline, nothing
installs) and walks you through every manual step with a checklist that remembers your
progress.

**Working with an AI agent?** Give it this folder in a fresh session and say "start";
it reads `START-HERE.md` and runs the full setup, including the secrets infrastructure
and the mandatory mini-course.

**Setting up by hand?** Read `ONBOARDING.md`, day 1 first (30 minutes, everything else
depends on it). Note: the agent path makes the secrets setup a day-1 step; the manual
path schedules it on day 6. Same system, same mandatory quiz, different order.

## Honesty, up front

- Some bundled skills are open source by other authors (MIT/Apache). They're included
  pre-configured as a convenience. You paid for the assembly, the conventions and the
  onboarding, not for their work. Links and licenses: `THIRD-PARTY.md`.
- This is a dated snapshot (v1, August 2026). No update subscription, no promises about
  future tooling. The structure and the reasoning are what age well.
- No revenue claims anywhere in this kit. It's a system for shipping and staying sane,
  not a get-rich playbook.
