#!/usr/bin/env node
// Agent-facing wrapper: reads the use-token from ~/.secrets/vault-token (cross-platform)
// and calls the proxy. The token never gets printed; the key never exists here at all.
// Usage: node vault-call.mjs <proxy-base> <secret-id> <path> [method] [json-body]
import { readFileSync } from "fs";
import { homedir } from "os";
import { join } from "path";

const [base, id, path, method = "GET", body] = process.argv.slice(2);
if (!base || !id || !path) {
  console.error("usage: node vault-call.mjs https://your-proxy.vercel.app <secret-id> <path> [method] [json]");
  process.exit(1);
}
const token = readFileSync(join(homedir(), ".secrets", "vault-token"), "utf8").trim();
const res = await fetch(`${base.replace(/\/$/, "")}/api/vault/proxy/${id}/${path}`, {
  method,
  headers: { authorization: `Bearer ${token}`, ...(body ? { "content-type": "application/json" } : {}) },
  body: body || undefined,
});
console.log(`HTTP ${res.status}`);
console.log(await res.text());
