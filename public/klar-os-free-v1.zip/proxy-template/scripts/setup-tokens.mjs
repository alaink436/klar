#!/usr/bin/env node
// Generates master key, use-token and admin password WITHOUT printing any of them.
// Cross-platform (no openssl, no HOME assumptions). Prints ONLY the vercel commands'
// success/failure and the sha256 hashes that go into env vars.
// Usage: node scripts/setup-tokens.mjs        (writes files + prints the 3 hashes/values to pipe)
import { randomBytes, createHash } from "crypto";
import { writeFileSync, mkdirSync, existsSync, readFileSync } from "fs";
import { homedir } from "os";
import { join } from "path";
import { execSync } from "child_process";

const dir = join(homedir(), ".secrets");
mkdirSync(dir, { recursive: true });

function ensure(file, bytes, encoding) {
  const p = join(dir, file);
  if (!existsSync(p)) writeFileSync(p, randomBytes(bytes).toString(encoding), { mode: 0o600 });
  return p;
}

const usePath = ensure("vault-token", 32, "hex");
const adminPath = ensure("vault-admin-token", 24, "hex");
const hash = (p) => createHash("sha256").update(readFileSync(p, "utf8").trim()).digest("hex");

// Re-runnable: skip vars that already exist (vercel env add errors on duplicates).
// NEVER auto-remove VAULT_MASTER_KEY: losing it makes every stored secret unreadable.
let existing = "";
try { existing = execSync("vercel env ls production", { encoding: "utf8" }); } catch {}

function setEnv(name, value, sensitive = false) {
  if (existing.includes(name)) {
    console.log(`${name} already set, skipped. (To rotate tokens: 'vercel env rm ${name} production', delete the matching ~/.secrets file, re-run. Never do this for VAULT_MASTER_KEY.)`);
    return;
  }
  execSync(`vercel env add ${name} production${sensitive ? " --sensitive" : ""}`, { input: value, stdio: ["pipe", "inherit", "inherit"] });
}

// Master key: generated in-memory, piped straight to vercel as a SENSITIVE var
// (write-only: not viewable in the dashboard afterwards), never written anywhere else.
setEnv("VAULT_MASTER_KEY", randomBytes(32).toString("base64"), true);
setEnv("USE_TOKEN_HASH", hash(usePath));
setEnv("ADMIN_TOKEN_HASH", hash(adminPath));

console.log("Done. Tokens live in ~/.secrets/ (vault-token for agents, vault-admin-token = your admin password).");
console.log("No secret value was printed. Redeploy with: vercel deploy --prod --yes");
