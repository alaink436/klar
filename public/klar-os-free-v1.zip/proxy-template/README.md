# vault-proxy: ready-to-deploy template

This is the complete use-but-don't-see secrets proxy. Agents (or the vault-proxy-setup
skill) COPY this folder instead of writing code from prose: less variance, fewer bugs.

## Deploy (agent-runnable, ~15 min)

```bash
cp -r proxy-template ~/vault-proxy
cd ~/vault-proxy
git init
git add -A
git commit -m "vault-proxy from Klar OS template"
gh repo create vault-proxy --private --source . --push
# 1. Create a dedicated Supabase project (free tier), run sql/schema.sql in its SQL editor
# 2. Set SUPABASE_URL + SUPABASE_SERVICE_ROLE_KEY in the Vercel dashboard (user pastes,
#    never the chat)
vercel deploy --prod --yes
node scripts/setup-tokens.mjs   # generates master key + tokens, no value printed
vercel deploy --prod --yes      # env vars live
```
⚠️ Never run `vercel env pull` here: a pulled `.env.local` would contain the master key.

Then: key window at `https://<your-app>/admin` (password: content of
`~/.secrets/vault-admin-token`; open the file yourself), agent calls via
`node scripts/vault-call.mjs <base> <secret-id> <path>`.

## What each piece is

- `app/api/vault/proxy/[id]/[...path]/route.js`, the proxy: validates use-token
  (sha256, constant-time), decrypts server-side, injects per auth_style, forwards,
  logs calls (never values).
- `app/admin/`, the key window: browser → server → encrypted row. Bulk entry, masked
  inputs, returns labels only.
- `scripts/setup-tokens.mjs`, cross-platform (Windows included): generates master key
  in-memory straight into a Vercel env var, tokens into `~/.secrets/`, prints nothing
  secret.
- `sql/schema.sql`, the store. RLS on, zero policies: service-role only.

## Iron rule
No key, token or connection string ever enters an AI chat. If an agent asks you to
paste one, the correct answer is no, and that request failing is the system working.
