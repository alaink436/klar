import { NextResponse } from "next/server";
import { encryptSecret, tokenMatches } from "../../../../lib/crypto";
import { db } from "../../../../lib/db";

// The key window's backend: browser -> here -> encrypted row. Returns labels only.
export async function POST(req) {
  const body = await req.json();
  if (!tokenMatches(body.adminToken, "ADMIN_TOKEN_HASH")) {
    return NextResponse.json({ error: "wrong admin password" }, { status: 401 });
  }
  const results = [];
  for (const row of body.secrets || []) {
    if (!row.label || !row.value) continue;
    if (row.base_url && !row.base_url.startsWith("https://")) {
      results.push({ label: row.label, ok: false, error: "base_url must be https" });
      continue;
    }
    const { nonce, ciphertext } = encryptSecret(row.value);
    // Upsert by label: re-entering a key under the same label ROTATES it in
    // place; the id stays stable, agents and wrappers stay unchanged.
    const { error } = await db().from("vault_secrets").upsert(
      {
        label: row.label,
        provider: row.provider || null,
        category: row.category || null,
        base_url: row.base_url || null,
        auth_style: row.auth_style || "bearer",
        ciphertext,
        nonce,
      },
      { onConflict: "label" }
    );
    results.push({ label: row.label, ok: !error });
  }
  return NextResponse.json({ stored: results });
}

export async function GET(req) {
  const token = req.headers.get("x-admin-token");
  if (!tokenMatches(token, "ADMIN_TOKEN_HASH")) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }
  const { data } = await db().from("vault_secrets").select("id,label,provider,base_url,auth_style,created_at").order("created_at");
  return NextResponse.json({ secrets: data || [] });
}
