import { NextResponse } from "next/server";
import { decryptSecret, tokenMatches } from "../../../../../../lib/crypto";
import { db } from "../../../../../../lib/db";

// use-but-don't-see: the caller holds a use-token; the key is injected server-side.
async function handle(req, { params }) {
  const auth = req.headers.get("authorization") || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : null;
  if (!tokenMatches(token, "USE_TOKEN_HASH")) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }

  const { id, path } = await params;
  const { data: secret, error } = await db()
    .from("vault_secrets")
    .select("id,label,base_url,auth_style,ciphertext,nonce")
    .eq("id", id)
    .single();
  if (error || !secret) return NextResponse.json({ error: "unknown secret" }, { status: 404 });
  if (!secret.base_url) return NextResponse.json({ error: "store-only secret, not proxyable" }, { status: 403 });

  const value = decryptSecret(secret.nonce, secret.ciphertext);
  const url = new URL(`${secret.base_url.replace(/\/$/, "")}/${(path || []).join("/")}`);
  req.nextUrl.searchParams.forEach((v, k) => url.searchParams.append(k, v));

  const headers = new Headers();
  const ct = req.headers.get("content-type");
  if (ct) headers.set("content-type", ct);
  const style = secret.auth_style || "bearer";
  if (style === "bearer") headers.set("authorization", `Bearer ${value}`);
  else if (style.startsWith("header:")) headers.set(style.slice(7), value);
  else if (style.startsWith("query:")) url.searchParams.set(style.slice(6), value);

  const body = ["GET", "HEAD"].includes(req.method) ? undefined : await req.arrayBuffer();
  // Log the CALL, never values, never bodies.
  console.log(JSON.stringify({ at: new Date().toISOString(), secret: secret.label, path: url.pathname, method: req.method }));

  const upstream = await fetch(url, { method: req.method, headers, body });
  return new NextResponse(upstream.body, {
    status: upstream.status,
    headers: { "content-type": upstream.headers.get("content-type") || "application/octet-stream" },
  });
}

export { handle as GET, handle as POST, handle as PUT, handle as PATCH, handle as DELETE };
