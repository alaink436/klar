"use client";
import { useState } from "react";

// The key window. Keys travel browser -> your server -> encrypted DB. Never a chat.
const EMPTY = { label: "", provider: "", base_url: "", auth_style: "bearer", value: "" };

// Provider templates. Picking one fills the base URL AND the auth style, which
// genuinely differ per provider: Anthropic wants the key on `x-api-key` with no
// scheme, most others a Bearer token, a few only accept it as a query param.
// Getting this wrong is the single most common reason a first proxy call 401s.
// base_url "" = account-specific or store-only, so you fill it in yourself.
const PRESETS = [
  { id: "openai", label: "OpenAI", provider: "openai", base_url: "https://api.openai.com", auth_style: "bearer", hint: "sk-proj-… / sk-…" },
  { id: "anthropic", label: "Anthropic (Claude)", provider: "anthropic", base_url: "https://api.anthropic.com", auth_style: "header:x-api-key", hint: "sk-ant-…" },
  { id: "gemini", label: "Google Gemini", provider: "google", base_url: "https://generativelanguage.googleapis.com", auth_style: "header:x-goog-api-key", hint: "AIza…" },
  { id: "groq", label: "Groq", provider: "groq", base_url: "https://api.groq.com/openai/v1", auth_style: "bearer", hint: "gsk_…" },
  { id: "openrouter", label: "OpenRouter", provider: "openrouter", base_url: "https://openrouter.ai/api/v1", auth_style: "bearer", hint: "sk-or-…" },
  { id: "stripe", label: "Stripe", provider: "stripe", base_url: "https://api.stripe.com", auth_style: "bearer", hint: "sk_live_… / sk_test_…" },
  { id: "resend", label: "Resend", provider: "resend", base_url: "https://api.resend.com", auth_style: "bearer", hint: "re_…" },
  { id: "brevo", label: "Brevo", provider: "brevo", base_url: "https://api.brevo.com/v3", auth_style: "header:api-key", hint: "xkeysib-…" },
  { id: "github", label: "GitHub", provider: "github", base_url: "https://api.github.com", auth_style: "bearer", hint: "ghp_… / github_pat_…" },
  { id: "vercel", label: "Vercel", provider: "vercel", base_url: "https://api.vercel.com", auth_style: "bearer", hint: "Vercel access token" },
  { id: "revenuecat", label: "RevenueCat", provider: "revenuecat", base_url: "https://api.revenuecat.com", auth_style: "bearer", hint: "sk_… (secret)" },
  { id: "n8n", label: "n8n (self-hosted / cloud)", provider: "n8n", base_url: "", auth_style: "header:x-n8n-api-key", hint: "your instance URL + JWT" },
  { id: "tmdb", label: "TMDB (v4 token)", provider: "tmdb", base_url: "https://api.themoviedb.org", auth_style: "bearer", hint: "eyJ… (v4)" },
  { id: "storeonly", label: "Store-only (never proxied)", provider: "", base_url: "", auth_style: "bearer", hint: "service-role keys, .p8 files, anything an agent must not reach even indirectly" },
];

const input = { padding: 6, border: "1px solid #ccc", borderRadius: 4, fontSize: 14 };

export default function Admin() {
  const [adminToken, setAdminToken] = useState("");
  const [rows, setRows] = useState([{ ...EMPTY }]);
  const [status, setStatus] = useState("");
  const [existing, setExisting] = useState(null);
  const [hints, setHints] = useState({});

  const set = (i, k, v) => setRows(rows.map((r, j) => (j === i ? { ...r, [k]: v } : r)));

  // Picking a template fills provider + URL + auth style, and leaves the label
  // and the key itself to you.
  function pickPreset(i, id) {
    const p = PRESETS.find((x) => x.id === id);
    setHints({ ...hints, [i]: p ? p.hint : "" });
    if (!p) return;
    setRows(
      rows.map((r, j) =>
        j === i
          ? { ...r, provider: p.provider, base_url: p.base_url, auth_style: p.auth_style, label: r.label || p.label }
          : r
      )
    );
  }

  async function load() {
    // Token travels in a header, never in the URL (URLs land in logs and history).
    const res = await fetch("/api/admin/secrets", { headers: { "x-admin-token": adminToken } });
    const j = await res.json();
    setExisting(res.ok ? j.secrets : []);
    setStatus(res.ok ? "" : "Wrong admin password.");
  }

  async function save() {
    setStatus("Storing…");
    const res = await fetch("/api/admin/secrets", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ adminToken, secrets: rows }),
    });
    const j = await res.json();
    if (!res.ok) return setStatus(j.error || "Failed.");
    setStatus(`Stored: ${j.stored.filter((s) => s.ok).map((s) => s.label).join(", ") || "nothing"}`);
    setRows([{ ...EMPTY }]);
    setHints({});
    load();
  }

  return (
    <main style={{ maxWidth: 760, margin: "3rem auto", fontFamily: "system-ui", padding: "0 1rem" }}>
      <h1>Vault key window</h1>
      <p style={{ color: "#666" }}>
        Keys entered here go straight to your server and are stored AES-256-GCM encrypted.
        They never touch any AI chat. The admin password is in <code>~/.secrets/vault-admin-token</code> on your machine.
      </p>
      <input type="password" placeholder="Admin password" value={adminToken}
        onChange={(e) => setAdminToken(e.target.value)} onBlur={load}
        style={{ ...input, width: "100%", padding: 8, marginBottom: 16 }} />

      {rows.map((r, i) => (
        <fieldset key={i} style={{ marginBottom: 12, border: "1px solid #ddd", borderRadius: 6, padding: 12 }}>
          <label style={{ display: "block", fontSize: 13, color: "#666", marginBottom: 6 }}>
            Template (fills URL + auth style)
          </label>
          <select
            defaultValue=""
            onChange={(e) => pickPreset(i, e.target.value)}
            style={{ ...input, width: "100%", padding: 7, marginBottom: 10 }}
          >
            <option value="">pick a provider, or fill in by hand</option>
            {PRESETS.map((p) => (
              <option key={p.id} value={p.id}>{p.label}</option>
            ))}
          </select>

          <div style={{ display: "flex", gap: 8, marginBottom: 6 }}>
            <input placeholder="Label (e.g. OpenAI prod)" value={r.label} onChange={(e) => set(i, "label", e.target.value)} style={{ ...input, flex: 1 }} />
            <input placeholder="Provider" value={r.provider} onChange={(e) => set(i, "provider", e.target.value)} style={{ ...input, flex: 1 }} />
          </div>
          <input placeholder="Base URL (https://api.openai.com); empty = store-only" value={r.base_url} onChange={(e) => set(i, "base_url", e.target.value)} style={{ ...input, width: "100%", marginBottom: 6 }} />
          <div style={{ display: "flex", gap: 8 }}>
            <input placeholder="bearer | header:X-Api-Key | query:key" value={r.auth_style} onChange={(e) => set(i, "auth_style", e.target.value)} style={{ ...input, flex: 1 }} />
            <input type="password" placeholder="THE KEY (masked)" value={r.value} onChange={(e) => set(i, "value", e.target.value)} style={{ ...input, flex: 1 }} />
          </div>
          {hints[i] ? (
            <p style={{ fontSize: 12, color: "#666", margin: "8px 0 0" }}>Expected key shape: {hints[i]}</p>
          ) : null}
        </fieldset>
      ))}
      <button onClick={() => setRows([...rows, { ...EMPTY }])} style={{ padding: 8, marginRight: 8 }}>+ another key</button>
      <button onClick={save} style={{ padding: 8, fontWeight: 700 }}>Store encrypted</button>
      <p>{status}</p>

      {existing && (
        <>
          <h2 style={{ marginTop: 24 }}>Stored ({existing.length})</h2>
          <ul>{existing.map((s) => <li key={s.id}><code>{s.id}</code> · {s.label} {s.base_url ? "" : "(store-only)"}</li>)}</ul>
          <p style={{ fontSize: 13, color: "#666" }}>
            Re-entering a label above rotates that key in place; the id stays, so nothing
            that calls it needs changing.
          </p>
        </>
      )}
    </main>
  );
}
