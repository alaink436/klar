create table if not exists vault_secrets (
  id uuid primary key default gen_random_uuid(),
  label text not null unique,  -- unique: re-entering a label rotates the key in place
  provider text,
  category text,
  base_url text,            -- NULL = store-only (not proxyable)
  auth_style text default 'bearer',  -- 'bearer' | 'header:X-Api-Key' | 'query:key'
  ciphertext text not null, -- AES-256-GCM, base64(ct||tag)
  nonce text not null,      -- base64, 12 bytes
  created_at timestamptz default now()
);
alter table vault_secrets enable row level security;
-- No policies on purpose: service-role only. The browser never reads this table
-- directly; the admin API returns labels, never values.
