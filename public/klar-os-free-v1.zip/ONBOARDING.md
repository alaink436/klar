# Onboarding: Day 1 to 7

Each day is 20 to 60 minutes. The order matters: every step assumes the previous one.

## Pick your pace first

Seven days is the unhurried version. Answer these four honestly:

1. Have you deployed a Next.js app to Vercel before?
2. Is git second nature (remotes, branches, pushing)?
3. Do you know what a reverse proxy is, and why an env var beats a file in the repo?
4. Do you already keep project notes in a system (Obsidian, Notion, plain Markdown)?

- **Mostly yes → one afternoon.** Days 1, 2 and 6 back to back (vault + first project +
  secrets proxy), then days 3 to 5 as you go. Nothing here is new to you except the
  conventions, and those you'll absorb faster by using them than by reading them.
- **Mixed → three evenings.** Day 1+2, then 3+4, then 6. Day 5 and 7 when they come up.
- **Mostly no → keep the seven days.** The pace is not padding: days 3 and 4 are habits,
  and habits need nights in between. You'll finish with a system you actually trust.

Running the agent path? Tell your agent the four answers up front. It calibrates how much
it explains, and skips nothing that matters, because the one non-negotiable (the
security quiz on day 6) is a check, not a lecture.

## Day 1: The vault exists, on GitHub (30 min)

**Before you start:** you need git and a GitHub account today; Node ≥ 20 plus free
Vercel and Supabase accounts for the secrets setup (day 6, or step 2 of the agent path).
Everything else is optional.

1. Copy the **entire kit folder** somewhere permanent (e.g. `~/klar-os`). Your vault is
   the `vault/` folder inside it; the whole kit stays together, because the setup uses
   `../proxy-template/` and the paid add-ons unpack next to it. Run `git init`
   at the kit root. Commit.
2. **Give it a remote. This is the system's backbone**, not an optional extra. Versioned
   history is what lets agents (and future you) trust the files, and the push at session
   end is what makes state survive machines:
   ```bash
   gh repo create my-vault --private --source . --push
   ```
   No GitHub CLI? Create a **private** repo in the web UI, then (three separate
   commands, works in every shell):
   ```bash
   git branch -M main
   git remote add origin <your-repo-url>
   git push -u origin main
   ```
   Private is non-negotiable: the vault will contain your business internals within a
   week. The included `.gitignore` keeps media and secrets out.
3. Second device (optional): clone the repo there; the pull at session start and push at
   session end ARE the sync. No sync service needed, and conflicts stay rare because the
   rituals serialize your sessions.
4. Open `CLAUDE.md` and read it once, top to bottom. You'll disagree with some rules.
   Fine, but every one of them was paid for with a real failure. The short reason is
   inline next to each rule; the full stories are the Playbook's first chapter (paid
   add-on). Don't delete a rule before you at least understand its inline reason.
5. Point your agent at the vault: for Claude Code, the vault's `CLAUDE.md` is loaded
   automatically when you work inside the vault; from other folders, reference it in your
   global `CLAUDE.md`.

## Day 2: Your first project moves in (30 min)
1. Duplicate `Projects/example-app/` for your most active real project.
2. Fill `PRD.md` with what the thing IS (stack, architecture, decisions). Fill
   `PROGRESS.md` with where it stands NOW. Follow the 80-line limit. It will hurt.
   The limit is the feature: an agent reads this file every session, and every line
   costs attention on unrelated work.
3. Add one row to `Projects/00-Registry.md` and one row to `STATUS.md`.

## Day 3: Session hygiene becomes muscle (30 min, then forever)
Start every agent session with the lookup ritual (it's in `CLAUDE.md`): STATUS first,
Registry second, Learnings-Index before debugging anything. End every substantial session
with the capture ritual: PROGRESS updated, STATUS row touched, commit, push.
Do it manually for a week before you automate anything. You need to feel the loop
before you can judge whether an automation of it is lying to you.

## Day 4: Learnings start compounding (20 min)
Take the last mistake that cost you more than an hour. Write it into the right category
file under `Learnings/` (create one: `engineering.md`, `store-review.md`, whatever fits),
THEN link it in `INDEX.md`. Category first, index second; the index carries titles only.
The scar behind this exact rule is in the playbook: 31 index entries once pointed at
learnings that were never written.

## Day 5: The Council sits (45 min)
Read `vault/Skills/Archive/llm-council/SKILL.md`, then run your first council on a real
decision you're currently avoiding. Not a trivial one: the council is for decisions
where being wrong is expensive. Use the peer-review round; it's where the value hides.
(The Playbook's chapter 02 adds the adaptations from six real sessions, including the
optimist-feedback pattern, the single biggest quality lever we found.)

## Day 6: Secrets stop leaking into contexts (60 min, optional but recommended)
Read `proxy-template/README.md` for the architecture, then don't build it by hand: tell
your agent to run **`vault/Skills/Archive/vault-proxy-setup/SKILL.md`** (if you started
via `START-HERE.md`, this already happened on day 1). It scaffolds and deploys
everything including the browser key window, and it closes with a mandatory quiz. The
quiz is not decoration: passing it is the difference between owning this system and
cargo-culting it. Note what the agent will NOT do: accept a key in chat. When it refuses,
that's the system working.

## Day 7: Review and prune (30 min)
Walk through everything you set up. Delete what you didn't use. The system's value is
inversely proportional to its size: the compactness rules exist because every stored
word is loaded into every future session. A lean vault that's alive beats a complete
vault that's noise.

**After week 1:** the system maintains itself through the session rituals. If a file grows
past its limit, compress it, don't append. If a rule keeps annoying you, read its scar;
if you still disagree after that, change it. It's your OS now.

---

## Thank you, and good luck

Seriously: thank you for setting this up properly instead of skimming it. You now run
the same system that ships real apps. What you build with it is the part no kit can
provide. Good luck out there.

- **Want the reasoning behind every rule you just adopted?** The failure stories, the
  council adaptations from six live sessions, the secrets deep-dive, real artifacts from
  the actual vault: the **Klar OS Playbook** → https://getklar.org/#pricing
- **Was this useful? Tell me.** When the Playbook ships, one email goes to the address
  you used for the download; reply to it with tips, criticism, or what you built.
  Every reply gets read by a human.
- **More from the person behind this:** https://getklar.org
