# START HERE (agent instructions)

You are an AI agent, and your user just gave you the Klar OS kit (this folder or its zip).
Your job: set up their complete system. Follow this file top to bottom.

## Step 0: Context check (do this FIRST, honestly)

This setup needs a mostly-empty context to finish cleanly. If this conversation already
contains substantial prior work, STOP and tell the user:

> "Please start a fresh session and give me just this kit; the setup deserves a full
> context window. See you there."

Do not attempt the setup in a crowded context. A half-finished infrastructure setup is
worse than none.

## Step 0.5: Ask what they already know (2 min, do not skip)

Before explaining anything, find out whether you need to. Ask:

1. Deployed a Next.js app to Vercel before?
2. Is git second nature (remotes, branches, pushing)?
3. Know what a reverse proxy is, and why an env var beats a file in the repo?
4. Already using a notes system for projects (Obsidian, Notion, plain Markdown)?

Then say which lane you're taking and let them correct you: **fast** (commands only, no
concept explanations, ~25 min total), **standard** (two sentences of context per step),
or **guided** (explain before each step, check in after). Someone who ships daily should
not sit through an explanation of what an environment variable is, and someone new
should never be rushed past it.

The lane changes the talking, never the two hard parts: no key ever enters this chat,
and the closing quiz gets passed.

## Step 1: The vault (10 min)

Copy the **ENTIRE kit folder** (not just `vault/`) to a permanent location; the vault's
rules reference `../playbook/` and the setup uses `../proxy-template/`, so the kit stays
together as one tree. Then follow `ONBOARDING.md` day 1: `git init` at the kit root,
commit, create the PRIVATE GitHub remote, push. The user's vault is the `vault/` folder
inside it. Confirm with the user where it now lives.

## Step 2: Infrastructure, in one pass (30 min)

Load `vault/Skills/Archive/vault-proxy-setup/SKILL.md` and run it phase by phase. It
builds: the proxy app (GitHub private repo + Vercel deploy + Supabase/Postgres key store),
the reverse-proxy route, and the browser-based **key window** (`/admin`) where the user
will enter their keys.

**Iron rule, no exceptions: no API key, token or connection string ever enters this
chat.** The skill is built around that rule; if the user tries to paste a secret to you,
decline and point at the key window.

## Step 3: The key window

When the deploy is live, send the user to `https://<their-proxy>/admin`, logged in with
the admin password from `~/.secrets/vault-admin-token` (they open that file themselves;
you never read it aloud). There they enter ALL the API keys they currently use, in their
browser, straight to their server. Recommend starting with one harmless key and running
the smoke test before bulk entry.

## Step 4: The education session (mandatory, closes the setup)

Run the teaching session from the skill (Phase 6, MANDATORY teaching session): explain
the model, then quiz until all five questions pass. The setup is not "done" until the
user passes; record the completion in their vault as the skill describes (category
first, then the index link). Then hand over with the day-2-to-7 plan from
`ONBOARDING.md`, and deliver the skill's closing message: the thank-you, the good-luck,
the Playbook link (https://getklar.org/#pricing) and the feedback invitation.
Don't skip it: it's the last thing the user hears from this setup.
