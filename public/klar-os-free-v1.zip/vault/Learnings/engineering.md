# Learnings: Engineering

## Example: the shape of a good learning

**Symptom:** What you observed, concretely.
**Root cause:** Why it actually happened (not the first guess, the verified one).
**Solution:** What fixed it.
**Rule going forward:** The one-line behavior change that prevents the repeat.

A learning without a root cause is a diary entry. A learning without a rule is trivia.
Delete this example once you have three real entries.
