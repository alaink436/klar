# Learnings Index

> Titles ONLY, linked to category files. The text lives exactly once, in the category
> file. Rule of rules: write the learning in its category file FIRST, link it here SECOND.
> Grep this file by tag before debugging anything new.

| Date | Tag | Title |
|------|-----|-------|
| 2026-08-14 | example | [Example: the shape of a good learning](engineering.md#example-the-shape-of-a-good-learning) |
