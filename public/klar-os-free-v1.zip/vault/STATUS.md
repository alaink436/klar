# Project Dashboard

> **Living overview.** Where does everything stand? Updated with every PROGRESS.md update
> (touch date + phase + next). Loaded at every session start; keep cells ≤ 200 characters.
> If a cell overflows: shorten, don't append. History belongs in the project's PROGRESS.md.

## 🔥 Active Now: touched ≤ 14 days

| Project | Touch | Phase / State | Next |
|---------|-------|---------------|------|
| example-app | 08-14 | 🆕 Day 0: PRD written, repo initialized, nothing shipped. | Build the walking skeleton · first TestFlight build |

## 🟢 Recently Active: 15-45 days

| Project | Touch | Phase / State | Next |
|---------|-------|---------------|------|

## ❄️ Quiet: > 45 days

| Project | Touch | Phase / State | Question |
|---------|-------|---------------|----------|

## 📦 Archived
See `Projects/00-Registry.md`; archived projects are never referenced in sessions.
