---
name: learnings-sync
description: "Pulls new learnings from the Klar OS feed into this vault, following the vault's own capture rules: category file first, index second. Trigger when the user says 'sync learnings', 'pull the new learnings', or at the start of a month. Requires an active Learnings Sync subscription token; without one the skill stops and says so rather than inventing entries."
---

# Learnings Sync

Someone else's scars, merged into your vault under your rules. This skill fetches
entries written since your last sync and appends them the way `CLAUDE.md`
demands, so a synced learning is indistinguishable in shape from one you wrote.

## Before you run

The token lives in `~/.secrets/klar-os-sync-token`, the same place the vault
token lives, for the same reason: it is read at call time and never printed.
If the file is missing, stop and tell the user where to get one. Do NOT ask
them to paste it into the chat.

## Phase 1 — Find out what is already here

Read `Learnings/INDEX.md` and take the newest date in the table. That date is
your `since`. If the index is empty, use the day the vault was created.

Never guess this from memory or from the last sync you remember. The index is
the record; a wrong `since` either re-imports duplicates or silently skips a
month.

## Phase 2 — Pull

```bash
curl -s -H "Authorization: Bearer $(cat ~/.secrets/klar-os-sync-token)" \
  "https://getklar.org/api/learnings/feed?since=YYYY-MM-DD"
```

Responses that are not 200 mean exactly what they say:
- **401** no token was sent. The file is empty or unreadable.
- **403** the subscription is not active. Say so plainly; do not retry in a loop.
- **503** the feed is not configured on the server. Not the user's problem, stop.

## Phase 3 — Merge, category file first

For each returned entry, in date order oldest to newest:

1. Append `entry.body` to `Learnings/<entry.file>` in this vault. Create the
   file if it does not exist.
2. Only then add its title to `Learnings/INDEX.md`, linked to the category file.

That order is not decoration. The rule exists because 31 index rows once pointed
at learnings that were never written, and agents cited them for months. An index
line without its text is worse than no line at all.

Mark the origin. A synced entry is someone else's evidence, not yours:

```
## [2026-08-14] Their title here
**Tags:** `tag`, `tag`  ·  _synced from Klar OS_
```

That marker matters later. When you are deciding whether to trust a rule, it is
the difference between "I hit this myself" and "someone else hit this and I
believed them".

## Phase 4 — Report, then stop

Tell the user how many entries were merged, into which files, and the new
newest date in the index. If zero came back, say zero: a quiet month is a
result, not a failure to be papered over.

Commit the vault with the paths named explicitly, never `git add -A`.
