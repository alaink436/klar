# Skill Registry

Skills live in `Archive/<name>/SKILL.md` and load on demand with an explicit read,
NEVER from an auto-load directory. Every skill in an auto-load folder is read at the
start of every session whether it is relevant or not, which taxes all your work forever.
That rule is the whole reason this registry exists.

---

## Shipped inside this kit

- `Archive/vault-proxy-setup/SKILL.md` — Klar Studios, MIT (this kit).
  Hand it to any agent and it builds your entire secrets infrastructure: private repo,
  deployment, encrypted key store, browser key window. Ends with a mandatory quiz that
  runs until you demonstrably understand the model, before any real key moves in.
  The agent will refuse to accept a key in chat. That refusal is the product working.

- `Archive/llm-council/SKILL.md` — tenfoldmarc, MIT. Method after Andrej Karpathy,
  Claude adaptation inspired by @olelehmann. Source and full license text ship next to
  the skill; see `THIRD-PARTY.md`.
  Five advisors with fixed thinking styles answer the same framed question in parallel,
  get anonymised, peer-review each other, and a chairman synthesises. For decisions where
  being wrong is expensive, never for facts or creation tasks.

- `Archive/learnings-sync/SKILL.md` — Klar Studios, MIT (this kit).
  Pulls new learnings from the Klar OS feed into this vault and merges them the
  way the capture ritual demands: category file first, index second, each entry
  marked as someone else's evidence rather than yours. Needs an active Learnings
  Sync subscription; without one it stops and says so instead of inventing
  entries. The token lives in `~/.secrets/klar-os-sync-token` and is read at call
  time, never printed.

---

## Curated, installed from the source

These are not redistributed here. The registry gives you the curation, the license and
the reason to load each one; you install them from their authors, which is both the
correct thing to do and how you get their updates.

| Set | Skills | Author | License | What it is for |
|-----|--------|--------|---------|----------------|
| Everything Claude Code | ~59 used here | Affaan Mustafa (`affaan-m/ECC`) | MIT | Engineering practice: API design, frontend and backend patterns, database migrations, deployment, testing, docker, cost-aware LLM routing, eval harnesses, agentic workflows |
| Impeccable | 18 | Paul Bakaus (`pbakaus/impeccable`) | Apache 2.0 | UI and UX quality: full design review plus focused passes (typeset, colorize, layout, polish, critique, harden). Based on Anthropic's frontend-design skill |
| HyperFrames | 19 | HeyGen (`heygen-com/hyperframes`) | Apache 2.0 | HTML plus a seekable timeline rendered to deterministic MP4. Ten creation workflows from product launch to talking-head recut |
| UI/UX Pro Max | 4 | Next Level Builder | MIT | Design, design systems, banner design, UI styling |

Install any of them from the author's repository, then place them in `Archive/` and add a
line here. The registry is the index; the skills stay where their licenses put them.

### Deliberately not listed

Some skill sets in wide circulation are missing from this registry on purpose. A skill
without a verifiable license is not a gift, it is a liability you inherit. Two categories
were kept out: sets whose license does not permit redistribution or bundling, and sets
whose provenance could not be established. If you add one yourself, record the author and
the license in this table first. The five minutes that costs is the cheapest legal
insurance in the kit.

---

## How to add a skill

1. Put it in `Archive/<name>/SKILL.md`, with its LICENSE file next to it if it has one.
2. Add a row here: what it is for, when to load it, who wrote it, under which license.
3. Never place it in an auto-load directory.
