# example-app: Progress

> Max ~80 lines, forever. Compress before adding. Specs belong in PRD.md.

## Current Status
One or two sentences: what phase, what state.

## Last Updated: YYYY-MM-DD
- Max 5 bullets, ONLY the latest session. Older sessions get condensed into Completed.

## Completed
- One line per finished phase/feature. No session detail.

## In Progress
- [ ] Checklist items, no prose.

## Known Issues
1. Max 5. Drop the oldest when solved.

## Problems Encountered (root cause + solution)
- Only recurring patterns, max 3-5. One-off problems don't earn a line here;
  cross-project ones go to Learnings instead.
