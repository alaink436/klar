# example-app: PRD

> WHAT the thing is. Stable facts: stack, architecture, decisions with reasons.
> State and history live in PROGRESS.md, never here.

## One-liner
One sentence: who gets what pain removed.

## Target user
Who exactly. Narrow beats broad: "25-200 employee firms in one city" beats "SMBs".

## Stack & architecture
Frameworks, backend, data model sketch. Decisions WITH the reason they were made,
so future sessions don't relitigate them.

## Decided (with reasons)
- Decision, because reason. (This section saves more agent-hours than any other.)

## Open questions
1. The honest list. An open question written down is one an agent can answer.
