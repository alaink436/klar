# Project Registry

> Single source of truth for project ↔ code path ↔ repo. Agents only reference projects
> with status Active / In Progress / Planning / Paused. Archived rows exist for humans.

| Project | Status | Code path | Repo | Notes |
|---------|--------|-----------|------|-------|
| example-app | Active | `~/code/example-app` | `github.com/you/example-app` | Replace me on day 2 |
