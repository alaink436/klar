# Vault Rules (loaded every session, keep this file lean)

> This file is read by your agent at the start of every session inside the vault.
> Every word here costs context in every future session. When in doubt: shorter.
> Short reasons are inline; the full failure stories behind each rule are in the
> Klar OS Playbook (a paid add-on; the free system works completely without it).

## Language & style
- Answers concise, no filler, no summary paragraphs at the end.
- Direct tools (glob/grep/read) over subagents for simple lookups.

## Lookup ritual (session start, BEFORE touching any project)
1. Read `STATUS.md`, the whole-portfolio picture: what's active, what's quiet, what's next.
2. Read `Projects/00-Registry.md` for project ↔ code-path ↔ repo mapping. Only reference
   projects marked Active / In Progress / Planning / Paused. Ignore Archived.
3. On any NEW problem: grep `Learnings/INDEX.md` by tag/title BEFORE trial-and-error.
   If a past mistake matches, read its category entry first.

## Capture ritual (session end, after substantial work)
1. Project state → that project's `PROGRESS.md` (compress first, then add).
2. Dashboard row → `STATUS.md` (touch date, phase, next action).
3. Cross-project learning (applies to ≥1 other project)? → write it in the matching
   `Learnings/<category>.md` FIRST, then link it in `INDEX.md`.
4. Commit and push the vault. Stage paths explicitly, never `git add -A`.

## PROGRESS.md rules (hard limits)
- Max ~80 lines per file. Compress when writing, don't grow.
- "Current Status": 1-2 sentences. "Last Updated": ONLY the latest session, max 5 bullets;
  older sessions get condensed into "Completed".
- Specs and architecture live in `PRD.md`, never duplicated in PROGRESS.
- Always read before updating: compress old content, then add new.

## STATUS.md + Learnings/INDEX.md (loaded every session, keep tiny)
- STATUS "Phase" cell: **≤ 200 characters.** One marker, one sentence. History belongs in
  the project's PROGRESS. If a cell overflows: shorten, don't append.
- Learnings INDEX carries **titles only**, linked to category files. The text lives exactly
  once, in the category file. Never index-first: category file first, then the index link.
- No images/video in the vault repo (it's a notes system, not asset storage; .gitignore them).

## Secrets
- No API keys in the vault, in chat, or in any committed file. A key that appears in a
  chat context counts as burned: rotate it.
- Agents use keys through the proxy pattern (`proxy-template/README.md`): use, never see.

## Skills (on-demand, NO auto-load)
- Skill archive lives in `Skills/Archive/<name>/SKILL.md`; load with a read WHEN relevant.
- Never write skills into your agent's auto-load directories (every session pays for them).

## Memory (if your agent has persistent memory)
- Save: user corrections, preferences, recurring patterns, external references.
- Do NOT save project state (that's PROGRESS.md's job) or anything derivable from the repo.

## Irreversible actions (money, releases, the outside world)
- Anything that costs money or reaches the public (builds, store submissions, OTA pushes
  to live users, publishing, sending) gets an explicit go from the human first. Prepare
  everything up to the gate, then ask. This rule has no exceptions, including "the fix is
  obvious" and "it's probably fine".
